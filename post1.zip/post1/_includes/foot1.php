<html>
<head>
<link rel="stylesheet" href="../_css/footer.css">
</head>
<body>
<div id="footer">
		<div class="sub_contents">
	<h2>Post and Sale Features</h2>
	<ul>
	<li><a href="#">Post Jobs</a></li>
	<li><a href="#">Find Jobs</a></li>
	<li><a href="#">Post Free Ads</a></li>
	</ul>
		</div>
	<div class="sub_contents">
	<h2>Use full Information</h2>
	<ul>
	<li><a href="#">Help </a></li>
	<li><a href="#">About site</a></li>
	<li><a href="contactus.php">Contact Us</a></li>
	</ul>
	
	</div>

	<div class="sub_contents">
	<h2>Get Connected</h2>
	<ul>	
	<div id="fblogo">
	 <a href="#">
	 <img src="_images/fblogo.png" alt="connect to facebook" width="40" height="40">
	</a>
	</div>
	<div id="twitlogo">
	<a href="#">
	<img src="_images/twitterlogo.png" alt="connect to twitter" width="40" height="40">
	</a>
	</ul>
	</div>
	</div>
	<div id="rights">
		<div id="ftext">
		<p> &copy Post and Sale (Pakistan)</p>
		</div>
	</div>
	


</body>
</html>
