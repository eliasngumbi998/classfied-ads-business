<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>footeer</title>

<link href="../_css/footeer.css" rel="stylesheet">
</head>

<body>
<div id="footall">
<div id="upimage">
</div>
<div id="bodyback">


</div>
</div>



</body>
</html>