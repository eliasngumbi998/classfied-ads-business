
<div class="ftall">
<div id="fline">
</div>

<div id="fbody">
<div id="contentsbody">
<div  id="content">
	<h2>Post and Sale Features</h2>
	<ul>
	<li><a href="post.php?page=34">Post Jobs</a></li>
	<li><a href="show.php?page=32">Find Jobs</a></li>
	<li><a href="category.php">Post Free Ads</a></li>
	</ul>
		</div>
	<div id="content">
	<h2>Use full Information</h2>
	<ul>
	<li><a href="#">Help </a></li>
	<li><a href="sitemap.php">Site Map</a></li>
	<li><a href="contactus.php">Contact Us</a></li>
	</ul>
	
	</div>

	<div  id="socialimg">
	<h2>Get Connected</h2>
	<ul>
    <div id="socialimgall">	
	 <a href="#">
	 <img src="_images/fblogo.png" alt="connect to facebook" width="40" height="40">
	</a>
	<a href="#">
	<img src="_images/twitterlogo.png" alt="connect to twitter" width="40" height="40">
	</a>
    <a href="#">
	<img src="_images/g+logo.png" alt="connect to twitter" width="40" height="40">
	</a>
    </ul>
	</div>
	
</div>
</div>

<div id="policy">
<a href="#" title="Post and Sale Privace Policy" target="_blank">Privacy Policy</a>
</div>
</div>
